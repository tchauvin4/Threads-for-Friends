
# Student Clothing Closet (Public)

Public website for students to browse and request free clothing. Requests are emailed to a coordinator, and (optionally) tracked inside Microsoft 365.

## Customize
1. Open `script.js` and `admin.html` and set `coordinatorEmail`.
2. Update `items.json` with your items (use `admin.html` to generate records).
3. Add or edit the list of schools in `script.js` (SCHOOLS array).

## Deploy (GitHub Pages)
1. Create a new GitHub repository.
2. Upload these files to the root of the repo.
3. Settings → Pages → Source: `main` branch → root. Wait ~1–2 minutes.

## Track Orders Automatically (Power Automate)
You can keep the site public while tracking internally:

**A. Create a shared mailbox** (optional): e.g., `closet@district.org`. Set your request email to this address.

**B. Build a flow (no-code):**
1. Go to Power Automate → Create → **Automated cloud flow**.
2. Trigger: **When a new email arrives (V3)** for the coordinator/shared mailbox; filter Subject contains `[Closet Request]`.
3. Action: **Html to text** (extract body). Optionally **Compose** and **Parse JSON** for fields.
4. Action: **Create item** in SharePoint List `Orders` with columns:
   - Title (text)
   - ItemId (text)
   - StudentName (text)
   - StudentEmail (text)
   - DeliverySchool (choice)
   - PreferredStyle (choice)
   - Notes (multiline)
   - Status (choice: New, Scheduled, Delivered)
   - ReceivedOn (date/time)
5. Action: **Post message** to a Teams channel for volunteers.
6. (Optional) Action: **Update Items list** (reserve the item) by setting status to `reserved`.

**C. SharePoint Lists**
Create two lists:
- **Items** (if you prefer internal management): ItemId, Title, Category, Fit, Gender, SizeType, Size, Condition, Status, ImageURL.
- **Orders**: as above.

## Safety & Accessibility
- No PII beyond school email, name, delivery school.
- Alt text and labels are included; maintain WCAG AA contrast.
- Use neutral backgrounds for item photos.

## Edit filters
- Fit: `Adult` or `Children`
- Gender style: `Gender-neutral`, `Men's`, `Women's`, `Kids`
- Sizes: Letter (XS–XXL) or Numeric (e.g., 3, 10, 30)

