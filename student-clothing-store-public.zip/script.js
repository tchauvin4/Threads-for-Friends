
// Public storefront with email-based requests. Orders can be tracked via Power Automate (see README).
const coordinatorEmail = "coordinator@example.org"; // replace with your email
const SCHOOLS = ["Rocklin High School", "Whitney High School", "Spring View Middle School", "Granite Oaks Middle School", "Sunset Ranch Elementary", "Twin Oaks Elementary", "Other (type school name)"];

const elGrid = document.getElementById('grid');
const elSearch = document.getElementById('search');
const elCategory = document.getElementById('category');
const elFit = document.getElementById('fit');
const elGender = document.getElementById('gender');
const elSizeLetter = document.getElementById('sizeLetter');
const elSizeNumber = document.getElementById('sizeNumber');
const elClear = document.getElementById('clearFilters');
const dialog = document.getElementById('requestDialog');
const form = document.getElementById('requestForm');
const itemSummary = document.getElementById('itemSummary');
const elDeliverySchool = document.getElementById('deliverySchool');

let items = [];
let activeItem = null;

// populate schools
function populateSchools() {
  elDeliverySchool.innerHTML = SCHOOLS.map(s => `<option>${s}</option>`).join('');
}

async function loadItems() {
  const res = await fetch('items.json');
  items = await res.json();
  render();
}

function matchesFilters(item) {
  const q = elSearch.value.trim().toLowerCase();
  const cat = elCategory.value;
  const fit = elFit.value; // Adult/Children
  const gender = elGender.value; // style label
  const sizeL = elSizeLetter.value; // XS-XXL
  const sizeN = elSizeNumber.value.trim(); // numeric text

  const text = `${item.title} ${item.description || ''} ${item.color || ''} ${item.brand || ''}`.toLowerCase();
  const qOk = (!q || text.includes(q));
  const catOk = (!cat || item.category === cat);
  const fitOk = (!fit || item.fit === fit);
  const genderOk = (!gender || item.gender === gender);
  const sizeOk = (
    (!sizeL && !sizeN) ||
    (item.sizeType === 'Letter' && sizeL && item.size === sizeL) ||
    (item.sizeType === 'Numeric' && sizeN && String(item.size) === sizeN)
  );
  return qOk && catOk && fitOk && genderOk && sizeOk;
}

function cardTemplate(item) {
  const disabled = item.status !== 'available';
  const statusLabel = item.status === 'available' ? 'Available' : 'Reserved';
  const alt = item.alt || `${item.title} - ${item.sizeType} ${item.size}`;
  const sizeBadge = item.sizeType === 'Letter' ? `Size ${item.size}` : `Size ${item.size}`;
  return `
    <article class="card" aria-label="${item.title} ${sizeBadge} ${item.condition}">
      <img src="${item.image}" alt="${alt}" loading="lazy" />
      <div class="content">
        <h3>${item.title}</h3>
        <div class="meta">
          <span class="badge">${item.category}</span>
          <span class="badge">${item.fit}</span>
          <span class="badge">${item.gender}</span>
          <span class="badge">${sizeBadge}</span>
          <span class="badge">${item.condition}</span>
          <span class="badge">${statusLabel}</span>
        </div>
        <p class="desc">${item.description || ''}</p>
      </div>
      <div class="actions">
        <button class="primary" ${disabled ? 'disabled' : ''} aria-disabled="${disabled}" onclick="requestItem('${item.id}')">Request</button>
      </div>
    </article>
  `;
}

function render() {
  const filtered = items.filter(matchesFilters);
  elGrid.setAttribute('aria-busy', 'true');
  elGrid.innerHTML = filtered.map(cardTemplate).join('');
  elGrid.setAttribute('aria-busy', 'false');
}

function requestItem(id) {
  activeItem = items.find(i => i.id === id);
  const sizeText = activeItem.sizeType === 'Letter' ? activeItem.size : String(activeItem.size);
  itemSummary.textContent = `${activeItem.title} (${activeItem.fit}, ${activeItem.gender}, size ${sizeText})`;
  dialog.showModal();
}

elSearch.addEventListener('input', render);
elCategory.addEventListener('change', render);
elFit.addEventListener('change', render);
elGender.addEventListener('change', render);
elSizeLetter.addEventListener('change', render);
elSizeNumber.addEventListener('input', render);
elClear.addEventListener('click', () => {
  elSearch.value=''; elCategory.value=''; elFit.value=''; elGender.value=''; elSizeLetter.value=''; elSizeNumber.value=''; render(); });

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(form));
  const school = data.school === 'Other (type school name)' ? (data.school_other || 'Other') : data.school;

  const subject = encodeURIComponent(`[Closet Request] ${activeItem.title} (${activeItem.fit}, ${activeItem.gender}, size ${activeItem.size}) → Deliver to ${school}`);
  const body = encodeURIComponent(
    `Item: ${activeItem.title}
Category: ${activeItem.category}
Fit: ${activeItem.fit}
Style: ${activeItem.gender}
Size: ${activeItem.sizeType} ${activeItem.size}
Condition: ${activeItem.condition}
Color/Brand: ${activeItem.color || ''} ${activeItem.brand || ''}

Deliver to school: ${school}
Student Name: ${data.name}
School Email: ${data.email}
Preferred style: ${data.pref_gender || 'No preference'}
Notes: ${data.notes || ''}

(Generated by Student Clothing Closet)`
  );
  window.location.href = `mailto:${coordinatorEmail}?subject=${subject}&body=${body}`;
  dialog.close();
});

populateSchools();
loadItems();
